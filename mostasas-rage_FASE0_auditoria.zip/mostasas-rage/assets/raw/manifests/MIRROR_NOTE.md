Los archivos de esta carpeta son ESPEJOS/RESÚMENES re-derivados durante la
FASE 0 desde los manifiestos originales de Google Drive (fileIds en
assets/DRIVE_INVENTORY.json → authoritativeManifests). Ante cualquier
discrepancia, el original de Drive manda hasta que FASE 1 descargue y
versione las copias byte-exactas.
