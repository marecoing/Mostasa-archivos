# Mostasa's Rage: Ciudad de la Furia
Beat 'em up 2.5D — Phaser 4 · TypeScript · Vite. Fuente de verdad:
`docs/BIBLIA_MAESTRA.txt`. Estado: FASE 0 (auditoría) completa; ver
`docs/production/STATUS.md`. Próximo paso: FASE 1 — Fundación.
