# IMPLEMENTATION PLAN — Mostasa's Rage (post-auditoría)

Basado en Biblia §36 (plan de producción) y ajustado al hallazgo central de
FASE 0: **hay arte base pero cero código**. Cada fase termina con typecheck,
tests, build, reporte y commit sugerido (regla principal de la Biblia).

## FASE 1 — FUNDACIÓN  ← SIGUIENTE
Salida: `npm run dev` levanta juego vacío a 1280×720 con letterbox.
- Vite + TypeScript strict + Phaser 4 (versión fijada + lockfile).
- Estructura §28: `src/game/{config,scenes,systems,...}`, `src/data/...`.
- Scenes: Boot, Preload, MainMenu, Gameplay, Pause, Results (stubs tipados).
- InputSystem (teclado según §7, buffers 100–180 ms) + bus de eventos tipados.
- `src/data/balance/defaultBalance.ts` con los valores del §8/§9.
- **Resolver GAP-01**: `stageManifest.ts` con mapeo ID-Biblia → artBundleId-Drive.
- Script `scripts/assets/pull_from_drive.py` (lee `assets/DRIVE_INVENTORY.json`,
  descarga bajo demanda; dry-run por defecto).
- Vitest + primer test (balance carga y valida) + lint/format + CI mínimo.
- Gate: typecheck ✅, tests ✅, build ✅, 0 secretos.

## FASE 2 — MOVIMIENTO
X/Z + salto Y (gravedad -22, jump 7.2), placeholder de Mostasa (cápsula),
orden por Z/pies, cámara con dead zone, gamepad. Gate: demo caminable.

## FASE 3 — COMBATE
Combos J-J-J / J-J-K, hitbox/hurtbox separadas, daños §9, hitstop, stagger,
grab/throw, bronca 0–100 + especial, score con bonus por variedad.
Gate: tests de daño/combo/bronca en verde.

## FASE 4 — IA
Entidad común data-driven (sin clase por enemigo), fichas de ataque por
dificultad, estados §10, pooling. Gate: 4 grunts simultáneos estables 60 FPS.

## FASE 5 — ESCENARIO 1 (Once)
5 paneles desde `panels_1024x1024/01-once/` (empalme §17), zonas y oleadas
por datos (presupuesto 3–6), pickups/armas desde manifest de objetos,
mini-boss 009 y boss 010 con fases, Pendrive Federal 01, resultados.
Gate: demo jugable 8–15 min de punta a punta.

## FASE 6 — ARTE Y AUDIO DEMO
Triage de las ~90 raw de `generated_images/`; pipeline B/C del §18 para
Mostasa (hoja 12×8) y enemigos 001–010; validación §20 con reportes;
integración de VFX del manifest; música/SFX/voces del Escenario 1.
⚠️ Requiere decisión de proveedor de imágenes + presupuesto (§19) — pedir
autorización antes de generar lotes.

## FASE 7 — UX · FASE 8 — COMERCIAL · FASES 9–10 — ESCENARIOS 2–10 · FASE 11 — BALANCE · FASE 12 — RC
Según Biblia §36 sin cambios. Nota FASE 9–10: gracias al material ya
existente (strips+paneles de los 10 escenarios), el cuello de botella será
personajes 011–100, no fondos.

## Reglas transversales (de la Biblia, verificadas en auditoría)
- No borrar assets; migraciones documentadas (§ regla principal).
- Data-driven siempre; una entidad común para 100 enemigos (§16).
- Nunca cargar 101 personajes juntos (§2 pilar 6).
- Sin claves en cliente ni en repo (§19, §39).
- Todo texto por localización, nada hardcodeado (§34).
