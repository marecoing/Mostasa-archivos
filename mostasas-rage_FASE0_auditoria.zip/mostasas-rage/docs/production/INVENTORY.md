# INVENTARIO — carpeta Drive "MOSTASAS RAGE" (FASE 0, 2026-07-15)

Fuente: https://drive.google.com/drive/folders/1UMwAHFmnuxLGntbsrLNN2EabrJE4xKgr
Mapa machine-readable con fileIds: `assets/DRIVE_INVENTORY.json`

## Árbol relevado

```
MOSTASAS RAGE/
└── ASSETS/
    ├── player/                         1 PNG  (00-mostasa, ref. canónica) + .gitkeep
    ├── characters/                     11 PNG (000–010, refs. canónicas, ~1 MB c/u)
    │   └── generated_images/019f5bc5…/ ~90 PNG raw (ig_<hash>.png, ~2 MB c/u, SIN clasificar)
    ├── enemies/                        10 PNG (001–010; duplicado byte-idéntico de characters/) + .gitkeep
    ├── scenarios_20260713_1348/
    │   ├── README.txt · scenario-manifest.json (10 stages) · scenario-strip-preview.png
    │   ├── raw_generated/              10 PNG fuente (~2.4–3.0 MB)
    │   ├── strips_5120x1024/           10 strips normalizados (~5.7–7.2 MB)
    │   └── panels_1024x1024/           10 subcarpetas × 5 paneles (01-once verificado: 5/5)
    └── object_sprites_20260713_1227/
        ├── README.txt · asset-manifest.json (61 objetos) · contact-sheet-preview.png
        ├── sheets_alpha/               10 hojas fuente transparentes (verificado 10/10)
        ├── sheets_magenta_clean/ · raw_sheets_magenta/   intermedios del pipeline
        └── pickups/ rewards/ weapons/ props/ ui/ destructibles/ vfx/   recortes finales
```

## Conteos clave

| Grupo | Cantidad | Estado según §19 |
|---|---|---|
| Referencias canónicas de personajes | 12 únicas (000–010 + copia en player/) | generated (sin validar) |
| Raw de personajes sin clasificar | ~90 | missing-triage |
| Strips de escenarios | 10/10 | generated |
| Paneles de escenarios | 50 declarados (5 verificados) | generated |
| Objetos con metadata | 61 (11 pickups, 5 rewards, 10 armas, 18 props, 5 UI, 6 destruibles×4, 6 VFX×6–8) | generated |
| Personajes 011–100 | 0 | missing |
| Audio | 0 | missing |
| Código | 0 | missing |

## Verificaciones realizadas vs. pendientes
- ✅ Listado completo de todas las carpetas de primer y segundo nivel.
- ✅ Lectura completa de los 2 manifiestos JSON y 2 READMEs.
- ✅ Consistencia manifest↔archivos en strips (10/10), sheets_alpha (10/10), panels de 01-once (5/5).
- ⏳ Pendiente (FASE 1/5): verificación por archivo de panels 02–10 y de los recortes finales de objetos; verificación de dimensiones reales de PNG (requiere descarga).
