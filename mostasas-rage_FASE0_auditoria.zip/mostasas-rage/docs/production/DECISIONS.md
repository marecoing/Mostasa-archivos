# DECISIONS — registro de decisiones y conflictos

## D-01 — Motor: Phaser 4 / TypeScript, no Unity (2026-07-15)
Conflicto: el skill operativo `build-game` describe un baseline Unity/C#,
pero la Biblia Maestra v3.0 (§1) define Phaser 4 + TypeScript + Vite + WebGL,
y la propia Biblia se declara fuente de verdad que reemplaza decisiones
anteriores. La instrucción explícita del usuario fue seguir la Biblia.
**Decisión:** stack de la Biblia (Phaser 4/TS). Reversible: no se escribió
código de motor todavía. El skill se sigue en todo lo demás (disciplina de
milestones, evidencia, honestidad de estado).

## D-02 — Mapeo de IDs de escenarios (2026-07-15)
Conflicto GAP-01: IDs del manifest de arte ≠ IDs canónicos de la Biblia §14.
**Decisión:** los IDs de la Biblia son canónicos en código y datos; el arte
se referencia vía campo `artBundleId`. No se renombra nada en Drive.
Se implementa en FASE 1. Reversible.

## D-03 — Binarios permanecen en Drive durante FASE 0 (2026-07-15)
~250 PNG (~500 MB estimados) no se descargaron en la auditoría: la fase no
lo requiere y el canal de descarga de esta sesión es ineficiente para
binarios masivos. **Decisión:** trazabilidad total vía
`assets/DRIVE_INVENTORY.json` (fileIds) y descarga programática bajo demanda
desde FASE 1/5. Los dos manifiestos JSON y READMEs de Drive sí fueron leídos
completos y espejados/resumidos en `assets/raw/manifests/` con procedencia.

## D-04 — Estructura documental (2026-07-15)
Conflicto menor: el skill pide `Documentation/PRODUCTION_STATE.json` (formato
Unity); la Biblia §40/§41 pide `docs/production/STATUS.md` y compañía.
**Decisión:** estructura de la Biblia. STATUS.md cumple el rol de estado de
producción; WORK_LOG.md registra la sesión.

## D-05 — Limpieza de directorios accidentales (2026-07-15)
Durante el setup, un fallo de expansión de shell creó directorios basura
vacíos (`{docs...}`). Se eliminaron por ser artefactos de esta misma sesión,
sin contenido de usuario. Ningún archivo del proyecto fue borrado.
